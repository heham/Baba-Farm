/*
 * @Author: TonyJiangWJ
 * @Date: 2019-12-23 22:54:22
 * @Last Modified by: TonyJiangWJ
 * @Last Modified time: 2020-08-04 20:28:06
 * @Description: 
 */
let { updateDownloader } = require('../lib/UpdateChecker.js')
updateDownloader.downloadUpdate()