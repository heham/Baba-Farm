let { historyDownloader } = require('../lib/UpdateChecker.js')
historyDownloader.downloadUpdate()